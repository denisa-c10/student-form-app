import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { FormService } from '../../services/form.service';
import { saveAs } from 'file-saver';

@Component({
  selector: 'app-student-form',
  templateUrl: './student-form.component.html',
  styleUrls: ['./student-form.component.scss']
})
export class StudentFormComponent {
  studentForm: FormGroup;
  motivationMinLength = 100;

  constructor(private fb: FormBuilder, private formService: FormService) {
    this.studentForm = this.fb.group({
      nume: ['', Validators.required],
      prenume: ['', Validators.required],
      facultate: ['', Validators.required],
      motivatie: ['', [Validators.required, Validators.minLength(this.motivationMinLength)]]
    });
  }

  onSubmit() {
    if (this.studentForm.valid) {
      this.formService.submitForm(this.studentForm.value).subscribe(
        (response: Blob) => {
          saveAs(response, `Fisa_Student_${this.studentForm.value.nume}_${this.studentForm.value.prenume}.pdf`);
          this.studentForm.reset();
        },
        (error) => {
          console.error('Error submitting form:', error);
          // Handle error display to the user
        }
      );
    } else {
      // Mark all controls as touched to display validation errors
      Object.values(this.studentForm.controls).forEach(control => {
        if (control.invalid) {
          control.markAsTouched();
        }
      });
    }
  }
}