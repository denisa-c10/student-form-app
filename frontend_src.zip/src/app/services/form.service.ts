import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class FormService {
  constructor(private http: HttpClient) {}

  submitForm(formData: any): Observable<Blob> {
    // Assuming there's an API endpoint that handles form submission and returns a PDF
    return this.http.post('http://your-api-endpoint/submit', formData, { responseType: 'blob' });
  }
}
