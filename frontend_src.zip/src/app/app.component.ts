import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { HttpClient} from '@angular/common/http';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  studentForm: FormGroup;

  constructor(private fb: FormBuilder, private http: HttpClient) { 
    this.studentForm = this.fb.group({
      nume: ['', Validators.required],
      prenume: ['', Validators.required],
      facultate: ['', Validators.required],
      motivatie: ['', Validators.required]
    });
  }

  onSubmit() {
    
      if (this.studentForm.invalid) {
        this.studentForm.markAllAsTouched();  
        return;
      }
    
      console.log('Trimit formularul:', this.studentForm.value);  // DEBUG
    
      this.http.post('http://localhost:5200/api/forms', this.studentForm.value, {
        responseType: 'blob'  
      }).subscribe({
        next: (response: Blob) => {
          console.log('Am primit PDF-ul!');
          const blob = new Blob([response], { type: 'application/pdf' });
          const url = window.URL.createObjectURL(blob);
          window.open(url);
        },
        error: (error) => {
          console.error('Eroare la trimiterea formularului:', error);
        }
      });
    }
    
  }
  
  
