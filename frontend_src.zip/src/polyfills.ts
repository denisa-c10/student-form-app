import 'zone.js';  // Included with Angular CLI.

/** Evergreen browsers require these. **/
import 'core-js/actual/promise';
import 'core-js/actual/symbol';
import 'core-js/actual/object';
import 'core-js/actual/function';
import 'core-js/actual/number';
import 'core-js/actual/math';
import 'core-js/actual/string';
import 'core-js/actual/date';
import 'core-js/actual/array';
import 'core-js/actual/iterator';
import 'core-js/actual/map';
import 'core-js/actual/set';
import 'core-js/actual/weak-map';
import 'core-js/actual/weak-set';

/** IE10 and IE11 require these for the Reflect API. */
import 'core-js/proposals/reflect-metadata';
