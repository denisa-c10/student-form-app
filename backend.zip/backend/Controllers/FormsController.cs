using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using StudentFormApp.Core.Models;  // Asigură-te că ai acest model
using StudentFormApi.Data;  // Asigură-te că folosești contextul corect
using DinkToPdf;
using DinkToPdf.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;

namespace StudentFormApp.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class FormsController : ControllerBase
    {
        private readonly ApplicationDbContext _context;

        private readonly IConverter _pdfConverter;

        // Constructor pentru injectarea contextului și converter-ului PDF
        public FormsController(ApplicationDbContext context, IConverter pdfConverter)
        {
            _context = context;
            _pdfConverter = pdfConverter;
        }

        // Endpoint pentru crearea formularului și generarea PDF-ului
        [HttpPost]
        public IActionResult CreateForm([FromBody] StudentForm form)
        {
            Console.WriteLine($"Form primit: {form.Nume} {form.Prenume}");
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);  // Returnează eroarea de validare
            }

            form.DataSubmisiei = DateTime.UtcNow;
            _context.StudentForms.Add(form);  // Adaugă formularul în DB
            _context.SaveChanges();  // Salvează formularul în baza de date

            var pdfBytes = GeneratePdf(form);  // Generează PDF-ul din formular
            return File(pdfBytes, "application/pdf", $"Fisa_Student_{form.Nume}_{form.Prenume}.pdf");  // Trimite PDF-ul ca răspuns
        }

        // Endpoint pentru a obține toate formularele din DB
        [HttpGet]
        public ActionResult<IEnumerable<StudentForm>> GetAllForms()
        {
            return _context.StudentForms.ToList();  // Returnează lista de formulare
        }

        // Endpoint pentru a obține un formular după ID
        [HttpGet("{id}")]
        public ActionResult<StudentForm> GetForm(int id)
        {
            var form = _context.StudentForms.Find(id);
            if (form == null)
            {
                return NotFound();  // Dacă formularul nu există, returnează 404
            }
            return form;
        }

        // Endpoint pentru actualizarea unui formular
        [HttpPut("{id}")]
        public IActionResult UpdateForm(int id, [FromBody] StudentForm updatedForm)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);  // Returnează eroarea de validare
            }

            if (id != updatedForm.Id)
            {
                return BadRequest();  // Dacă ID-ul nu se potrivește, returnează eroare
            }

            var existingForm = _context.StudentForms.Find(id);
            if (existingForm == null)
            {
                return NotFound();  // Dacă formularul nu există, returnează 404
            }

            // Actualizează formularul cu noile valori
            existingForm.Nume = updatedForm.Nume;
            existingForm.Prenume = updatedForm.Prenume;
            existingForm.Facultate = updatedForm.Facultate;
            existingForm.Motivatie = updatedForm.Motivatie;

            try
            {
                _context.SaveChanges();  // Salvează modificările
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!FormExists(id))
                {
                    return NotFound();  // Dacă formularul nu există, returnează 404
                }
                else
                {
                    throw;
                }
            }

            return NoContent();  // Returnează 204 (No Content) dacă actualizarea a avut succes
        }

        // Endpoint pentru ștergerea unui formular
        [HttpDelete("{id}")]
        public IActionResult DeleteForm(int id)
        {
            var form = _context.StudentForms.Find(id);
            if (form == null)
            {
                return NotFound();  // Dacă formularul nu există, returnează 404
            }

            _context.StudentForms.Remove(form);  // Șterge formularul din DB
            _context.SaveChanges();  // Salvează modificările

            return NoContent();  // Returnează 204 (No Content) dacă ștergerea a avut succes
        }

        // Metodă privată pentru generarea PDF-ului din formular
        private byte[] GeneratePdf(StudentForm form)
        {

            var pdfConverter = new SynchronizedConverter(new PdfTools());
            var doc = new HtmlToPdfDocument()
            {
                GlobalSettings = new GlobalSettings
                {
                    ColorMode = ColorMode.Color,
                    Orientation = Orientation.Portrait,
                    PaperSize = PaperKind.A4,
                },
                Objects = {
        new ObjectSettings()
        {
            HtmlContent = $@"
                <html>
                    <head><title>Student Form</title></head>
                    <body>
                        <h1>{form.Nume} {form.Prenume}</h1>
                        <p>Facultate: {form.Facultate}</p>
                        <p>Motivatie: {form.Motivatie}</p>
                    </body>
                </html>",
            WebSettings = new WebSettings()
            {
                LoadImages = true
            }
        }
    }
            };

            // Specifică calea către `wkhtmltopdf`
            var pdfBytes = pdfConverter.Convert(doc);


            return _pdfConverter.Convert(doc);  // Generează și returnează PDF-ul
        }

        // Verifică dacă formularul există în DB
        private bool FormExists(int id)
        {
            return _context.StudentForms.Any(e => e.Id == id);
        }
    }
}
