using System;
using System.ComponentModel.DataAnnotations;
namespace StudentFormApp.Core.Models
{
    public class StudentForm
    {
        public int Id { get; set; }
        public required string Nume { get; set; }
        public required string Prenume { get; set; }
        public required string Facultate { get; set; }
        public required string Motivatie { get; set; }
        public DateTime DataSubmisiei { get; set; } = DateTime.UtcNow;
    }
}