using Microsoft.EntityFrameworkCore;
using StudentFormApp.Core.Models; // Importă modelul corect

namespace StudentFormApi.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
        {
        }

        public DbSet<StudentForm> StudentForms { get; set; } = null!;
    }
}
